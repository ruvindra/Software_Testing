export default {
  testEnvironment: "node",
};